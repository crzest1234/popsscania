DATABASE_URL='sqlite:///./propscan.db'
SECRET_KEY='changeme'
